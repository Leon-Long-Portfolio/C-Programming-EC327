# EC327_project

This is the code to build a basic flashcard app which will later be integrated with the calendar app
