package com.project327.projectprocrastination.model

class Card(var word: String, var meaning: String, var number: Int = Int.MAX_VALUE)