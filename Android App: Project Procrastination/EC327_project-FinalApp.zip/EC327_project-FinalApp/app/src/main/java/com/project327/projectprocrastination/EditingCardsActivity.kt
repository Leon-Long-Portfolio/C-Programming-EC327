package com.project327.projectprocrastination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.widget.AdapterView
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.get
import androidx.core.view.size
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.project327.projectprocrastination.model.CardAdapter
import com.project327.projectprocrastination.model.Card

class EditingCardsActivity : AppCompatActivity() {
    private lateinit var cardsStorage: SharedPreferences
    private lateinit var cardList: ListView
    private var uuid: Long = 0L
    private var actionMode: ActionMode? = null
    private val selectedPositions: MutableList<Int> = mutableListOf()
    private val actionModeCallBack = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode?, menu: Menu?): Boolean {
            mode?.menuInflater?.inflate(R.menu.context_menu, menu)
            return true
        }

        override fun onActionItemClicked(mode: ActionMode?, item: MenuItem?): Boolean {
            return when (item?.itemId) {
                R.id.context_menu_delete -> {
                    for (i in cardList.count - 1 downTo 0) {
                        if (selectedPositions.contains(i)) {
                            (cardList.adapter as CardAdapter).remove(i)
                        }
                    }
                    val cardListData = (cardList.adapter as CardAdapter).objects
                    cardListData.forEachIndexed { i, card -> card.number = i }

                    // save card list to th sharedPreferences
                    val editor = cardsStorage.edit()
                    editor.putString(uuid.toString(), Gson().toJson(cardListData))
                    editor.apply()
                    selectedPositions.clear()
                    cardList.choiceMode = ListView.CHOICE_MODE_NONE
                    // finish the context mode
                    mode?.finish()
                    true
                }
                else -> false
            }
        }

        override fun onDestroyActionMode(mode: ActionMode?) {
            selectedPositions.clear()
            for (i in 0 until cardList.size) {
                cardList[i].setBackgroundColor(Color.TRANSPARENT)
            }
            cardList.choiceMode = ListView.CHOICE_MODE_NONE
            actionMode = null
        }

        override fun onPrepareActionMode(mode: ActionMode?, menu: Menu?): Boolean = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editing_cards)


        // initialize private fields
        cardsStorage = getSharedPreferences("cards", Context.MODE_PRIVATE)
        cardList = findViewById(R.id.card_list)
        uuid = intent.getLongExtra("uuid", 0L)
        cardsStorage.getString(uuid.toString(), null)

        getCards()

        cardList.setOnItemLongClickListener { _, view, position, _ ->
            // when you long-tapped an item, if you are not in action mode, you will be into action mode
            if (actionMode == null) {
                actionMode = startActionMode(actionModeCallBack)
                cardList.choiceMode = ListView.CHOICE_MODE_MULTIPLE
                selectedPositions.add(position)
                view.setBackgroundColor(Color.LTGRAY)
            } else {
                if (selectedPositions.contains(position)) {
                    selectedPositions.remove(position)
                    view.setBackgroundColor(Color.TRANSPARENT)
                } else {
                    selectedPositions.add(position)
                    view.setBackgroundColor(Color.LTGRAY)
                }
            }
            true
        }
        cardList.onItemClickListener = AdapterView.OnItemClickListener { _, view, position, _ ->
            if (actionMode != null) {
                if (selectedPositions.contains(position)) {
                    selectedPositions.remove(position)
                    view.setBackgroundColor(Color.TRANSPARENT)
                } else {
                    selectedPositions.add(position)
                    view.setBackgroundColor(Color.LTGRAY)
                }
            } else {
                val intent = Intent(this, CreatingCardActivity::class.java)
                intent.putExtra("uuid", uuid)
                intent.putExtra("number", position)
                startActivity(intent)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        getCards()
    }

    private fun getCards() {
        val json = cardsStorage.getString(uuid.toString(), null)
        val cards = if (json == null) {
            mutableListOf()
        } else {
            Gson().fromJson<MutableList<Card>>(json, object : TypeToken<MutableList<Card>>() {}.type)
        }
        // add a number for the card
        cards.forEachIndexed { i, card -> card.number = i }

        cardList.adapter = CardAdapter(this, R.layout.layout_card, cards)
    }
}
