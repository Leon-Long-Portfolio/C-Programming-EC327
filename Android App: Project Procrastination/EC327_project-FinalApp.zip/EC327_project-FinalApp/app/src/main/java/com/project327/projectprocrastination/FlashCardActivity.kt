package com.project327.projectprocrastination

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.project327.projectprocrastination.model.Card

class FlashCardActivity : AppCompatActivity() {
    private lateinit var cardsStorage: SharedPreferences
    private lateinit var word: TextView
    private lateinit var meaning: TextView
    private lateinit var counter: TextView
    private lateinit var cards: MutableList<Card>
    private var uuid: Long = 0L
    private var cardNumber: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flash_card)

        // initialize private fields
        cardsStorage = getSharedPreferences("cards", Context.MODE_PRIVATE)
        word = findViewById(R.id.word)
        meaning = findViewById(R.id.meaning)
        counter = findViewById(R.id.counter)
        uuid = intent.getLongExtra("uuid", 0L)

        // this listener forces the alpha animation to stop
        meaning.setOnClickListener { view ->
            view.clearAnimation()
            view.alpha = 1f
            redrawFadeScrollbar()
        }
        showAnswerLittleByLittle()

        // TextView in the card will be scrollable
        meaning.movementMethod = ScrollingMovementMethod()

        val json = cardsStorage.getString(uuid.toString(), null)
        cards = if (json == null) {
            mutableListOf()
        } else {
            Gson().fromJson(json, object : TypeToken<MutableList<Card>>() {}.type)
        }

        // random display
        cards.shuffle()

        counter.text = String.format("%d / %d", cardNumber + 1, cards.size)

        if (cards.isEmpty()) {
            return
        }

        val card = cards[cardNumber]
        word.text = card.word
        meaning.text = card.meaning
    }

    @Suppress("UNUSED_PARAMETER")
    fun next(view: View) {
        cardNumber++
        if (cardNumber >= cards.size) {
            finish()
            return
        }
        counter.text = String.format("%d / %d", cardNumber + 1, cards.size)

        showAnswerLittleByLittle()

        val card = cards[cardNumber]
        word.text = card.word
        meaning.text = card.meaning

        redrawFadeScrollbar()
        meaning.scrollY = 0
    }

    @Suppress("UNUSED_PARAMETER")
    fun previous(view: View) {
        cardNumber--
        if (cardNumber < 0) {
            finish()
            return
        }
        counter.text = String.format("%d / %d", cardNumber + 1, cards.size)

        showAnswerLittleByLittle()

        val card = cards[cardNumber]
        word.text = card.word
        meaning.text = card.meaning

        redrawFadeScrollbar()
        meaning.scrollY = 0
    }

    private fun redrawFadeScrollbar() {
        meaning.scrollBy(0, 1)
        meaning.scrollBy(0, -1)
    }

    private fun showAnswerLittleByLittle() {
        val alphaAnimation = AlphaAnimation(0f, 1f)
        alphaAnimation.startOffset = 2000
        alphaAnimation.duration = 3000
        meaning.startAnimation(alphaAnimation)
    }
}
