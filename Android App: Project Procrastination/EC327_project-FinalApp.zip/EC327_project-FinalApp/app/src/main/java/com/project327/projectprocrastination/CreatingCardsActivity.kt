package com.project327.projectprocrastination

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.project327.projectprocrastination.model.Card

class CreatingCardActivity : AppCompatActivity() {
    private lateinit var cardsStorage: SharedPreferences
    private lateinit var wordInput: EditText
    private lateinit var meaningInput: EditText
    private lateinit var cards: MutableList<Card>
    private var uuid: Long = 0L
    private var number: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_creating_cards)




        // initialize private fields
        cardsStorage = getSharedPreferences("cards", Context.MODE_PRIVATE)
        wordInput = findViewById(R.id.word_input)
        meaningInput = findViewById(R.id.meaning_input)
        uuid = intent.getLongExtra("uuid", 0L)
        // if you get positive number, you are in edit mode
        number = intent.getIntExtra("number", -1)

        if (number > -1) {
            title = getString(R.string.page_title_editing)
            findViewById<Button>(R.id.creating_add_more).isEnabled = false
            val json = cardsStorage.getString(uuid.toString(), null)
            cards = if (json == null) {
                mutableListOf()
            } else {
                Gson().fromJson(json, object : TypeToken<MutableList<Card>>() {}.type)
            }
            wordInput.setText(cards[number].word)
            meaningInput.setText(cards[number].meaning)
        }

        wordInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = Unit
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                findViewById<Button>(R.id.creating_ok).isEnabled = !(s!!.isBlank() || meaningInput.text.isBlank())
                findViewById<Button>(R.id.creating_add_more).isEnabled = number < 0 && !(s.isBlank() || meaningInput.text.isBlank())
            }
        })

        meaningInput.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = Unit
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                findViewById<Button>(R.id.creating_ok).isEnabled = !(s!!.isBlank() || wordInput.text.isBlank())
                findViewById<Button>(R.id.creating_add_more).isEnabled = number < 0 && !(s.isBlank() || wordInput.text.isBlank())
            }
        })
    }


    /**
     * finish the activity
     */
    @Suppress("UNUSED_PARAMETER")
    fun cancel(view: View) {
        finish()
    }

    /**
     * add a card into the deck
     */
    @Suppress("UNUSED_PARAMETER")
    fun add(view: View) {
        val result = addCard()
        if (result) {
            showToast(getString(R.string.creating_toast_message_success))
            finish()
        } else {
            showToast(getString(R.string.creating_toast_message_failed))
        }
    }

    /**
     * add a card into the deck and continue to add a next card
     */
    @Suppress("UNUSED_PARAMETER")
    fun addMore(view: View) {
        val result = addCard()
        if (result) {
            showToast(getString(R.string.creating_toast_message_success))
            wordInput.setText("")
            meaningInput.setText("")
        } else {
            showToast(getString(R.string.creating_toast_message_failed))
        }
    }

    private fun addCard(): Boolean {
        val json = cardsStorage.getString(uuid.toString(), null)
        val cards = if (json == null) {
            mutableListOf<Card>()
        } else {
            Gson().fromJson(json, object : TypeToken<MutableList<Card>>() {}.type)
        }

        // when in edit mode, you will overwrite the card. If it's not, add a new card
        if (number > -1) {
            cards[number].word = wordInput.text.toString()
            cards[number].meaning = meaningInput.text.toString()
        } else {
            if (cards.none { it.word == wordInput.text.toString() }) {
                cards.add(Card(wordInput.text.toString(), meaningInput.text.toString()))
            } else {
                return false
            }
        }

        // add a number for the card
        cards.forEachIndexed { i, card -> card.number = i }

        // save the card
        val editor = cardsStorage.edit()
        editor.putString(uuid.toString(), Gson().toJson(cards))
        editor.apply()
        return true
    }

    private fun showToast(text: String, duration: Int = Toast.LENGTH_SHORT) {
        val toast = Toast.makeText(this, text, duration)
        toast.show()
    }
}
