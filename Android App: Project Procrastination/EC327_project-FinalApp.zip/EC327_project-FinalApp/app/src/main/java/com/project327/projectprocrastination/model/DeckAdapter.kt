package com.project327.projectprocrastination.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.project327.projectprocrastination.R

class DeckAdapter(context: Context, private val resource: Int, val objects: MutableList<Deck>) : BaseAdapter() {
    private val layoutInflater: LayoutInflater = LayoutInflater.from(context)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = this.layoutInflater.inflate(resource, null, false)
        view.findViewById<TextView>(R.id.title).text = this.objects[position].title
        return view
    }

    override fun getItem(position: Int): Any {
        return this.objects[position]
    }

    override fun getItemId(position: Int): Long {
        return this.objects[position].uuid
    }

    override fun getCount(): Int {
        return this.objects.size
    }

    fun remove(position: Int) {
        this.objects.removeAt(position)
        this.notifyDataSetChanged()
    }

    fun add(deck: Deck) {
        this.objects.add(deck)
    }
}