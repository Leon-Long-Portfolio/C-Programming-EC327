package com.project327.projectprocrastination.model

import java.util.*

class Deck(var title: String, var order: Int = Int.MAX_VALUE) {
    val uuid: Long = UUID.randomUUID().mostSignificantBits
}