package com.project327.projectprocrastination

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.AdapterContextMenuInfo
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.project327.projectprocrastination.model.Card
import com.project327.projectprocrastination.model.Deck
import com.project327.projectprocrastination.model.DeckAdapter
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*



class MainActivity : AppCompatActivity() {

    private lateinit var launchDateStorage: SharedPreferences
    private lateinit var decksStorage: SharedPreferences
    private lateinit var cardsStorage: SharedPreferences
    private lateinit var deckList: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn.setOnClickListener {
            val intent = Intent(this, CalendarActivity::class.java)
            // start your next activity
            startActivity(intent)
        }

        // initialize private fields
        launchDateStorage = getSharedPreferences("last-launch-date", Context.MODE_PRIVATE)
        decksStorage      = getSharedPreferences("decks",            Context.MODE_PRIVATE)
        cardsStorage      = getSharedPreferences("cards",            Context.MODE_PRIVATE)
        deckList          = findViewById(R.id.deck_list)

        deckList.setOnItemClickListener { _: AdapterView<*>, _: View, position: Int, _: Long ->
            val uuid = deckList.adapter.getItemId(position)
            val json = cardsStorage.getString(uuid.toString(), null)
            val cards: MutableList<Card> = if (json == null) {
                mutableListOf()
            } else {
                Gson().fromJson(json, object : TypeToken<MutableList<Card>>() {}.type)
            }

            if (cards.isEmpty()) {
                val toast = Toast.makeText(this, getString(R.string.no_cards), Toast.LENGTH_SHORT)
                toast.show()
            } else {
                val intent = Intent(this, FlashCardActivity::class.java).apply {
                    putExtra("uuid", uuid)
                }
                startActivity(intent)
            }
        }


        // get decks json from sharedPreferences
        val json = decksStorage.getString("decks", null)


        // initialize decks
        val decks = if (json == null) {
            mutableListOf<Deck>()
        } else {
            Gson().fromJson(json, object : TypeToken<MutableList<Deck>>() {}.type)
        }

        // sort by Deck.order
        decks.sortBy { it.order }

        // set contents to deckList
        deckList.adapter = DeckAdapter(this, R.layout.layout_deck, decks)

        val lastLaunchDate = launchDateStorage.getString("last-launch-date", null)
        // when you need to parse string date to date, you can use below.
        // SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.ENGLISH).parse("Sun Jun 30 20:40:40 GMT+09:00 2019")
        if (lastLaunchDate == null) {
            // set a sample deck and its cards
            val sampleDeck = Deck("Sample Deck", 0)
            (deckList.adapter as DeckAdapter).add(sampleDeck)
            val sampleCards = mutableListOf(Card("¡Hola!", "Hello!", 0), Card("¿Cómo estás?", "How are you?", 1), Card("Lo siento.", "I'm sorry", 2))
            val deckEditor = decksStorage.edit()
            deckEditor.putString("decks", Gson().toJson((deckList.adapter as DeckAdapter).objects))
            deckEditor.apply()
            val cardEditor = cardsStorage.edit()
            cardEditor.putString(sampleDeck.uuid.toString(), Gson().toJson(sampleCards))
            cardEditor.apply()
        }

        val launchDateEditor = launchDateStorage.edit()
        launchDateEditor.putString("last-launch-date", Date().toString())
        launchDateEditor.apply()

        // register a context menu to the deck list.
        // then the context menu will be to display when you long-tapped an item on the deck list.
        registerForContextMenu(deckList)
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.action_option, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        if (item == null) {
            return true
        }

        val info = item.menuInfo as AdapterContextMenuInfo
        return when (item.itemId) {
            // rename the deck
            R.id.rename -> {
                // create an edit text for the alert dialog
                val editText = TextInputEditText(this)

                val alertDialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Deck Title")
                    .setView(editText)
                    .setPositiveButton("OK") { _, _ ->
                        val deck = deckList.adapter.getItem(info.position) as Deck
                        deck.title = editText.text.toString()
                        val editor = decksStorage.edit()
                        editor.putString("decks", Gson().toJson((deckList.adapter as DeckAdapter).objects))
                        editor.apply()
                    }
                    .setNegativeButton("Cancel", null)
                    .create()

                // configure editText
                editText.inputType = InputType.TYPE_CLASS_TEXT
                editText.hint = "Rename the deck title"
                editText.setText((deckList.adapter as DeckAdapter).objects[info.position].title)
                editText.addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) = Unit
                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = s!!.isNotBlank()
                    }
                })

                alertDialog.show()
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
                true
            }
            // add cards in the deck
            R.id.add -> {
                val intent = Intent(this, CreatingCardActivity::class.java).apply {
                    putExtra("uuid", (deckList.adapter.getItem(info.position) as Deck).uuid)
                }
                startActivity(intent)
                true
            }

            // edit cards in the deck
            R.id.edit -> {
                val intent = Intent(this, EditingCardsActivity::class.java).apply {
                    putExtra("uuid", (deckList.adapter.getItem(info.position) as Deck).uuid)
                }
                startActivity(intent)
                true
            }

            // delete the deck
            R.id.delete -> {
                val deckAdapter = (deckList.adapter as DeckAdapter)

                // delete related cards
                val deck = deckAdapter.getItem(info.position) as Deck
                val cardsEditor = cardsStorage.edit()
                cardsEditor.remove(deck.uuid.toString())
                cardsEditor.apply()

                // delete the deck
                deckAdapter.remove(info.position)
                val decksEditor = decksStorage.edit()
                decksEditor.putString("decks", Gson().toJson(deckAdapter.objects))
                decksEditor.apply()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun showTitleDialog(view: View) {
        // create an edit text for the alert dialog
        val editText = TextInputEditText(this)
        val alertDialog = MaterialAlertDialogBuilder(this)
            .setTitle("Deck Title")
            .setView(editText)
            .setPositiveButton("OK") { _, _ ->
                val deckAdapter = (deckList.adapter as DeckAdapter)
                deckAdapter.add(Deck(editText.text.toString()))
                deckAdapter.objects.forEachIndexed { i, deck -> deck.order = i }
                val editor = decksStorage.edit()
                editor.putString("decks", Gson().toJson(deckAdapter.objects))
                editor.apply()
            }
            .setNegativeButton("Cancel", null)
            .create()

        // configure editText
        editText.inputType = InputType.TYPE_CLASS_TEXT
        editText.hint = "Enter a deck title"
        editText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = Unit
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = s!!.isNotBlank()
            }
        })

        alertDialog.show()
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE).isEnabled = false
    }
}
