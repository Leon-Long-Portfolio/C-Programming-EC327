package com.project327.projectprocrastination.model

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.project327.projectprocrastination.R
import com.project327.projectprocrastination.model.Card

class CardAdapter(context: Context, private val resource: Int, val objects: MutableList<Card>) : BaseAdapter() {
    private val layoutInflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val linearLayout = layoutInflater.inflate(resource, parent, false)
        val textView = linearLayout.findViewById<TextView>(R.id.title)
        textView.text = this.objects[position].word
        return linearLayout
    }

    override fun getItem(position: Int): Any {
        return this.objects[position]
    }

    override fun getItemId(position: Int): Long {
        return this.objects[position].number.toLong()
    }

    override fun getCount(): Int {
        return this.objects.size
    }

    fun remove(position: Int) {
        this.objects.removeAt(position)
        this.notifyDataSetChanged()
    }
}